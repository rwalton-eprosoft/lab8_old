//
//  DataSyncService.m
//  edgesync
//
//  Created by Vijaykumar on 5/30/13.
//  Copyright (c) 2013 eprosoft. All rights reserved.
//

#import "DataSyncService.h"
#import "AFJSONRequestOperation.h"
#import "AppDelegate.h"
#import "Constants.h"
#import "RegistrationModel.h"
#import "DataValidator.h"
#define APP_DELEGATE (AppDelegate*)[[UIApplication sharedApplication] delegate]
@interface DataSyncService ()

@end

@implementation DataSyncService

//Check if there are any updates for existing specialities
- (void)checkSpecialitySyncStatus : (NSString*) urlString withRequestData: (NSDictionary*) data usingHttpMethod:(NSString*) httpMethod
     withEmailId : (NSString*) emailId  withPassword : (NSString*) password
{
    [self invokeWebService :urlString usingHttpMethod:httpMethod withRequestData: data forEmailId:emailId forPassword:password checkSyncStatus:YES];
}


//Sync Server data with Core Data Locally
- (void)syncData : (NSString*) urlString withRequestData: (NSDictionary*) data usingHttpMethod:(NSString*) httpMethod
                    withEmailId : (NSString*) emailId  withPassword : (NSString*) password
{
    
    [self invokeWebService :urlString usingHttpMethod:httpMethod withRequestData: data forEmailId:emailId forPassword:password checkSyncStatus:NO];
}

//Sync Server data with Core Data Locally -- Deprecated Method
- (void)syncData : (NSString*) urlString withRequestData: (NSDictionary*) data usingHttpMethod:(NSString*) httpMethod
{
    
    [self invokeWebService :urlString usingHttpMethod:httpMethod withRequestData: data forEmailId:@"demo@example.com" forPassword:@"demo" checkSyncStatus:NO];
}

//Save data to Core Data, notify if any failures
- (void)processServerData:(NSHTTPURLResponse *)response JSON:(id)JSON checkSyncStatus : (BOOL) checkSyncStatus
{
    NSDictionary *jsonHeader = [(NSDictionary *) JSON valueForKey:SERVER_RESPONSE_HEADER];
    if (response.statusCode != 200 || (jsonHeader != nil &&
                                       [[jsonHeader valueForKey:@"statusCode"] intValue] != [[NSNumber numberWithInt:kSuccessContent] intValue])) {
        if (!checkSyncStatus) {
            [[NSNotificationCenter defaultCenter] postNotificationName:APP_EVENT_SYNC_MASTER_DATA_FAILURE object:nil userInfo:jsonHeader];
        } else {
            [[NSNotificationCenter defaultCenter] postNotificationName:APP_EVENT_VERIFY_SYNC_DATA_FAILURE object:nil userInfo:jsonHeader];
        }
        return;
    }
    
    if (!checkSyncStatus) {
        NSDictionary *jsonDict = [(NSDictionary *) JSON valueForKey:SERVER_RESPONSE_BODY];
        [self processJSONData :jsonDict];
        [APP_DELEGATE postApplicationEvent:APP_EVENT_SYNC_MASTER_DATA_SUCCESS];
    } else {
        [[NSNotificationCenter defaultCenter] postNotificationName:APP_EVENT_VERIFY_SYNC_DATA_SUCCESS object:nil userInfo:jsonHeader];
    }
}

/**
 Invokes a web service call
 */
- (void) invokeWebService : (NSString*) urlString usingHttpMethod:(NSString*) httpMethod withRequestData: (NSDictionary*) data
forEmailId : (NSString*) emailId  forPassword : (NSString*) password checkSyncStatus: (BOOL) status
{
    
    NSURL *url = [NSURL URLWithString:urlString];
    _httpClient = [[AFHTTPClient alloc] initWithBaseURL:url];
    [_httpClient registerHTTPOperationClass:[AFJSONRequestOperation class]];
    [_httpClient setDefaultHeader:HTTP_HEADER_ACCEPT value:HTTP_APPLICATION_JSON];
    _httpClient.parameterEncoding = AFJSONParameterEncoding;
    
    NSString *filepath = [url path];
    NSMutableURLRequest *request = [_httpClient requestWithMethod:httpMethod path:filepath parameters:data];
    [request setValue:emailId forHTTPHeaderField:HTTP_X_ASCCPE_USERNAME];
    [request setValue:password forHTTPHeaderField:HTTP_X_ASCCPE_PASSWORD];
    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObjects:HTTP_APPLICATION_JSON, nil]];
    AFJSONRequestOperation *operation =
    [AFJSONRequestOperation JSONRequestOperationWithRequest:request
        success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON)
        {
            NSLog(@"%@", JSON);
            [self processServerData:response JSON:JSON checkSyncStatus:status];
        }
        failure:^(NSURLRequest *request,
                  NSHTTPURLResponse *response, NSError *error, id JSON) {
            NSLog(@"Request Failure Because %@",[error userInfo]);
            [APP_DELEGATE postApplicationEvent:APP_EVENT_SYNC_MASTER_DATA_FAILURE];
        }
     ];
    [_httpClient enqueueHTTPRequestOperation:operation];
}

//Populate data for each Entity in Core Data and build Relations
- (void) processJSONData :(NSDictionary*) jsonDict
{
    NSLog(@"Generating data for MedicalCategory");
    [self populateCoreDataForEntity:@"MedicalCategory" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ArcCategory");
    [self populateCoreDataForEntity:@"ArcCategory" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ProcedureStep");
    [self populateCoreDataForEntity:@"ProcedureStep" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for SpecialityCategory");
    [self populateCoreDataForEntity:@"SpecialityCategory" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Content");
    [self populateCoreDataForEntity:@"Content" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ContentCategory");
    [self populateCoreDataForEntity:@"ContentCategory" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ContentMapping");
    [self populateCoreDataForEntity:@"ContentMapping" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Speciality");
    [self populateCoreDataForEntity:@"Speciality" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Procedure");
    [self populateCoreDataForEntity:@"Procedure" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Market");
    [self populateCoreDataForEntity:@"Market" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ProductCategory");
    [self populateCoreDataForEntity:@"ProductCategory" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Product");
    [self populateCoreDataForEntity:@"Product" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for CompProduct");
    [self populateCoreDataForEntity:@"CompProduct" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for FileContent");
    [self populateCoreDataForEntity:@"FileContent" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Applications");
    [self populateCoreDataForEntity:@"Applications" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for ExtendedMetadata");
    [self populateCoreDataForEntity:@"ExtendedMetadata" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Concern");
    [self populateCoreDataForEntity:@"Concern" forJSONResponse:jsonDict];
    
    NSLog(@"Generating data for Relations");
    [self populateCoreDataForEntity:@"Relations" forJSONResponse:jsonDict];
    
    NSLog(@"Generating Relation for Entitlements To Specialities");
    [[RegistrationModel sharedInstance] relateEntitlementsToSpecialities];

    NSEntityDescription *entity = [NSEntityDescription entityForName:@"MedicalCategory"
                                              inManagedObjectContext:[APP_DELEGATE managedObjectContext]];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entity];
    
    DataValidator* dq = [[DataValidator alloc] init];
    [dq getContentByContentCategory];
    NSLog(@"%@...", [dq report]);
}

/**
 Populates data for each single entity in Core Data.
 */
- (void) populateCoreDataForEntity :(NSString*) entityName forJSONResponse:(NSDictionary*) dataDict
{
    
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSArray* jsonArray = [dataDict objectForKey:entityName];
    if ([entityName isEqualToString:@"Relations"]) {
        [self processRelations :jsonArray :context];
        return;
    }
    
    int cnt = 0;
    for (NSDictionary* data in jsonArray) {
        if (![self isNewInsert:data forEntity:entityName withManagedObjectContext:context]) continue; //If the status is "1" (Insert) and if Persistance store already has a record, ignore...
        
        //For update or delete, no need for insertNewObjectForEntityForName
        if (([data objectForKey:ATTR_STATUS] == [NSNumber numberWithInt:2]
             || [data objectForKey:ATTR_STATUS] == [NSNumber numberWithInt:3])
            && ![entityName isEqualToString:ENT_FILECONTENT]) {     //Ignore FileContent for delete, let download logic remove file+record
            [self executeCoreDataAction :data forManagedObjectContext:context forEntityName:entityName];
            continue;
        }
        
        NSManagedObject *managedObject = [NSEntityDescription
                                          insertNewObjectForEntityForName:entityName
                                          inManagedObjectContext:context];
        
        NSDictionary *attributes = [[managedObject entity] attributesByName];
        for (NSString *attribute in attributes) {
            id value = [data objectForKey:attribute];
            if (value == nil || [value isKindOfClass:[NSNull class]]) {
                continue;
            }
            [self convertValueToProperType:attribute attributes:attributes forValue:&value];
            [managedObject setValue:value forKey:attribute];
        }
        [self executeCoreDataAction :managedObject forManagedObjectContext:context forEntityName:entityName];
        cnt++;
    }
    NSLog(@"populateCoreDataForEntity cnt: %d", cnt);
}

/**
 Check if a record already exists.
 */
- (BOOL) isNewInsert : (NSDictionary*) data forEntity : (NSString*) entityName withManagedObjectContext: (NSManagedObjectContext*) context
{
    
    NSArray *array = [self fetchManagedObjectByPrimaryKey:data withManagedObjectContext:context forEntityName:entityName];
    return ((array.count > 0 && ([data objectForKey:ATTR_STATUS] == [NSNumber numberWithInt:1]))? FALSE : TRUE);
}

/**
 Helper method
 */
- (NSString*)convertFirstLetterToLowerCase:(NSString *)relation
{
    return [relation stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[relation substringToIndex:1] lowercaseString]];
}

/**
 Processes each relation as per the relations sent by server in json array
 */
- (void) processRelations :(NSArray*) jsonArray :(NSManagedObjectContext* ) context
{
    NSError* error;
    for (NSDictionary* relations in jsonArray) {
        for (NSString* relation in [relations keyEnumerator]) {
            NSArray* relationEntities = [relation componentsSeparatedByString: @"To"];
            NSString* fromEntity = [relationEntities objectAtIndex:0];
            NSString* toEntity = [relationEntities objectAtIndex:1];
            NSLog(@"Executing relation for : %@", relation);
            if ([relation isEqualToString:@"ProcedureToProcedureStep"]) {
                NSLog(@"ProcedureToProcedureStep......./");
            }
            if (![self isValidRelation :relation]) continue;
            NSArray* values = [relations objectForKey:relation];
            NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
            NSArray* childObjects;
            NSArray* parentObject;
            for (NSDictionary* subrelation in values) {
                for (NSString* relationAttribute in [subrelation keyEnumerator]) {  //This is for child objects
                    if ([[subrelation objectForKey:relationAttribute] isKindOfClass:[NSArray class]]) {
                        NSEntityDescription *entity = [NSEntityDescription entityForName:toEntity inManagedObjectContext:[APP_DELEGATE managedObjectContext]];
                        [fetchRequest setEntity:entity];
                        NSString* predicateString = [self buildPredicateWithFieldName :relationAttribute values:[subrelation objectForKey:relationAttribute]];
                        predicateString = [predicateString stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                        NSLog(@"predicateString ..... Child %@", predicateString);
                        NSPredicate *predicate;
                        predicate = [NSPredicate predicateWithFormat:predicateString];
                        [fetchRequest setPredicate:predicate];
                        childObjects = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchRequest error:&error];
                    } else {                                                        //This is the parent object
                        NSEntityDescription *entity = [NSEntityDescription entityForName:fromEntity inManagedObjectContext:[APP_DELEGATE managedObjectContext]];
                        [fetchRequest setEntity:entity];
                        NSMutableArray* tempArray = [[NSMutableArray alloc] init];
                        [tempArray addObject:[subrelation objectForKey:relationAttribute]];
                        NSString* predicateString = [self buildPredicateWithFieldName :relationAttribute values:tempArray];
                        NSPredicate *predicate;
                        predicateString = [predicateString stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                        NSLog(@"predicateString ..... Parent %@", predicateString);
                        predicate = [NSPredicate predicateWithFormat:predicateString];
                        [fetchRequest setPredicate:predicate];
                        parentObject = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchRequest error:&error];
                    }
                }
                @try {
                    NSSet *tempSet = [NSSet setWithArray:childObjects];
                    [[parentObject objectAtIndex:0] setValue:tempSet forKey:[self convertFirstLetterToLowerCase:relation]];
                    NSLog(@"ParentObject : %@, ChildSet : %@, RelationName : %@", parentObject, childObjects , [self convertFirstLetterToLowerCase:relation]);
                    if (![context save:&error]) NSLog(@"Couldn't save: %@", [error localizedDescription]);
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception.... for Relation : %@, Exception : %@", [self convertFirstLetterToLowerCase:relation], exception);
                }
                @finally {
                    
                }
            }
        }
    }
}

/**
 *
 */
- (NSString*) buildPredicateWithFieldName : (NSString*) fieldName values :(NSArray*) values
{
    
    BOOL predicateWithSingleQuote = [self isFieldNameRequiresValueInSingleQuote:fieldName]; //Some string values require single quotes
    NSString* predicateString;
    if (values != nil && values.count > 0) {
        if (!predicateWithSingleQuote) {
            predicateString = [NSString stringWithFormat:@"(%@ == %@)", fieldName, values[0]];
            for (int i = 1; i < values.count; i++) {
                predicateString = [predicateString stringByAppendingString:[NSString stringWithFormat:@" OR (%@ == %@)", fieldName, values[i]]];
            }
        } else {
            predicateString = [NSString stringWithFormat:@"(%@ == '%@')", fieldName, values[0]];
            for (int i = 1; i < values.count; i++) {
                predicateString = [predicateString stringByAppendingString:[NSString stringWithFormat:@" OR (%@ == '%@')", fieldName, values[i]]];
            }
        }
    } else {
        NSLog(@"Values for Field Name %@ is nil", fieldName);
    }
    return predicateString;
}

- (BOOL) isFieldNameRequiresValueInSingleQuote : (NSString*) fieldName
{
    
    if ([fieldName isEqualToString:ATTR_PATH]) {
        return TRUE;
    }
    return FALSE;
}

/**
 *
 */
- (void) executeCoreDataAction :(id) managedObject  forManagedObjectContext:(NSManagedObjectContext* ) context
                  forEntityName:(NSString*) entityName
{
    
    NSError *error;
    if ([managedObject valueForKey:ATTR_STATUS] ==  [NSNumber numberWithInt:1]) {        //Save
        if (![context save:&error]) NSLog(@"Couldn't save: %@", [error localizedDescription]);
        
    } else if ([managedObject valueForKey:ATTR_STATUS] ==  [NSNumber numberWithInt:2]) { //Update
        NSArray* array = [self fetchManagedObjectByPrimaryKey : managedObject
                                      withManagedObjectContext: context
                                                 forEntityName: entityName];
        
        if (array != nil && array.count > 0) {
            [self updateEntityFrom:managedObject forEntityName:entityName toManagedObject:[array objectAtIndex:0]];
            if (![context save:&error]) NSLog(@"Couldn't save: %@", [error localizedDescription]);
        } else {
            NSLog(@"Invalid Data from Server, %@ ", managedObject);
        }
        
    } else if ([managedObject valueForKey:ATTR_STATUS] == [NSNumber numberWithInt:3]) {  //Delete
        
        if ([entityName isEqualToString:ENT_FILECONTENT]) {
            
            NSLog(@"entityName .... entityName ");
            if (![context save:&error]) NSLog(@"Couldn't save: %@", [error localizedDescription]); //Do not process delete for FileContent as we process within downloads.
            return;
            
        }
        
        NSArray* array = [self fetchManagedObjectByPrimaryKey : managedObject
                                      withManagedObjectContext: context
                                                 forEntityName: entityName];
        
        if (array != nil && array.count > 0) {
            [context deleteObject:[array objectAtIndex:0]]; //should return only one object
            if (![context save:&error]) NSLog(@"Couldn't save: %@", [error localizedDescription]);
        } else {
            NSLog(@"Invalid Data from Server, %@ ", managedObject);
        }
    }
}

/**
 *
 */
- (NSArray*) fetchManagedObjectByPrimaryKey :(id) managedObject
                    withManagedObjectContext:(NSManagedObjectContext* ) context
                               forEntityName:(NSString*) entityName {
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc] init];
    fetch.entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    NSString* predicateString;
    if ([[self getPrimaryKeyAttribute :entityName] isEqualToString:ATTR_PATH]) //Handle special case for path (String)
        predicateString = [NSString stringWithFormat:@"%@ == '%@'", [self getPrimaryKeyAttribute :entityName], [managedObject valueForKey:[self getPrimaryKeyAttribute :entityName]]];
    else
        predicateString = [NSString stringWithFormat:@"%@ == %@", [self getPrimaryKeyAttribute :entityName], [managedObject valueForKey:[self getPrimaryKeyAttribute :entityName]]];
    
    predicateString = [predicateString stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    fetch.predicate = [NSPredicate predicateWithFormat:predicateString];
    NSArray *array = [context executeFetchRequest:fetch error:nil];
    return array;
}

/**
 
 */
- (void) updateEntityFrom :(id) from forEntityName:(NSString*) entityName toManagedObject:(NSManagedObject*) to {
    
    NSDictionary *attributes = [[to entity] attributesByName];
    for (NSString *attribute in attributes) {
        id value = [from valueForKey:attribute];
        if (value == nil) {
            continue;
        }
        [self convertValueToProperType:attribute attributes:attributes forValue:&value];
        [to setValue:value forKey:attribute];
    }
}

/**
 
 */
- (void)convertValueToProperType:(NSString *)attribute attributes:(NSDictionary *)attributes forValue:(id *)value
{
    NSAttributeType attributeType = [[attributes objectForKey:attribute] attributeType];
    if ((attributeType == NSStringAttributeType) && ([*value isKindOfClass:[NSNumber class]])) {
        *value = [*value stringValue];
    } else if (((attributeType == NSInteger16AttributeType) || (attributeType == NSInteger32AttributeType) || (attributeType == NSInteger64AttributeType) || (attributeType == NSBooleanAttributeType)) && ([*value isKindOfClass:[NSString class]])) {
        *value = [NSNumber numberWithInteger:[*value  integerValue]];
    } else if ((attributeType == NSFloatAttributeType) && ([*value isKindOfClass:[NSString class]])) {
        *value = [NSNumber numberWithDouble:[*value doubleValue]];
    } else if ((attributeType == NSDateAttributeType) && ([*value isKindOfClass:[NSString class]])) {
        *value = [*value stringByReplacingOccurrencesOfString:@"\"<null>\"" withString:@""];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM/dd/yyyy"];
        NSDate* dateFromString = [dateFormatter dateFromString:*value];
        *value = dateFromString;
    }
}

/**
 
 */
- (NSString*) getPrimaryKeyAttribute : (NSString*) entity {
    
    if ([entity isEqualToString:@"Product"])
        return @"prodId";
    else if ([entity isEqualToString:@"Procedure"])
        return @"procId";
    else if ([entity isEqualToString:@"ProcedureStep"])
        return @"procStepId";
    else if ([entity isEqualToString:@"ContentCategory"])
        return @"contentCatId";
    else if ([entity isEqualToString:@"ArcCategory"])
        return @"arcCatId";
    else if ([entity isEqualToString:@"Speciality"])
        return @"splId";
    else if ([entity isEqualToString:@"Content"])
        return @"cntId";
    else if ([entity isEqualToString:@"MedicalCategory"])
        return @"medCatId";
    else if ([entity isEqualToString:@"ContentMapping"])
        return @"cntMapId";
    else if ([entity isEqualToString:@"CompProduct"])
        return @"compProdId";
    else if ([entity isEqualToString:@"Market"])
        return @"mktId";
    else if ([entity isEqualToString:@"SpecialityCategory"])
        return @"splCatId";
    else if ([entity isEqualToString:@"ProductCategory"])
        return @"prodCatId";
    else if ([entity isEqualToString:@"Concern"])
        return @"concernId";
    else if ([entity isEqualToString:@"ExtendedMetadata"])
        return @"cntExtFieldId";
    else if ([entity isEqualToString:@"FileContent"])
        return @"path";
    return nil;
}

/**
 */
- (void) deleteAllFromEntityWithName:(NSString*)entityName
{
    // Create the fetch request for the entity.
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    // Edit the entity name as appropriate.
    NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:[APP_DELEGATE managedObjectContext]];
    
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSArray *items = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if (!error) {
        if (items && items.count > 0)
        {
            for (NSManagedObject *item in items)
            {
                [[APP_DELEGATE managedObjectContext] deleteObject:item];
            }
            [APP_DELEGATE saveContext];
        }
    }
}

/**
 *
 */
- (void) deleteSpecialityById : (NSNumber*) splId
      withManagedObjectContext:(NSManagedObjectContext* ) context {
    
    //Speciality
    NSMutableArray* values = [[NSMutableArray alloc] init];
    [values addObject:[NSNumber numberWithInt:[splId intValue]]];
    NSArray *specialities = [self fetchManagedObjectByPrimaryKeys :values withManagedObjectContext:context forEntityName:ENT_SPECIALITY];
    if (specialities != nil && specialities.count > 0) {
        
        //Procedure
        NSMutableArray* specialityIds = [self prepareValuesArrayFromManagedObjects :specialities :@"Procedure" :@"splId"];
        NSArray* procedures = [self fetchByForeignKey:ATTR_SPLID :@"Procedure" :context :specialityIds];
        if (procedures != nil && procedures.count > 0) {
            
            //Product
            NSMutableArray* procedureIds = [self prepareValuesArrayFromManagedObjects :procedures :@"Product" :@"procId"];
            NSArray* products = [self fetchByForeignKey:ATTR_SPLID :@"Product" :context :procedureIds];
            for (NSManagedObject* product in products)
                [context deleteObject:product];
        }
        for (NSManagedObject* speciality in specialities)
            [context deleteObject:speciality];
        NSError* error;
        if (![context save:&error])
            NSLog(@"Couldn't save: %@", [error localizedDescription]);
        else
            NSLog(@"Successfully deleted speciality with id %@" , splId);
    }
    
    //Delete data from Content Mapping and Content Entities
}

- (NSArray*) fetchByForeignKey :(NSString*) foreignKey :(NSString*) entityName :(NSManagedObjectContext* ) context :(NSArray*) values {
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc] init];
    fetch.entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    NSString* predicateString;
    NSString* predicate = [self buildPredicateWithFieldName:foreignKey values:values];
    predicateString = [predicate stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    fetch.predicate = [NSPredicate predicateWithFormat:predicateString];
    NSArray *array2 = [context executeFetchRequest:fetch error:nil];
    return array2;
}

- (NSMutableArray*) prepareValuesArrayFromManagedObjects :(NSArray*) managedObjects :(NSString*) entityName  : (NSString*) key {
    NSMutableArray* values = [[NSMutableArray alloc] init];
    for (id entity in managedObjects) {
        NSNumber* value = [entity valueForKey:key];
        [values addObject:value];
    }
    return values;
}

/**
 */
- (NSArray*) fetchManagedObjectByPrimaryKeys :(NSArray*) values
                     withManagedObjectContext:(NSManagedObjectContext*) context
                                forEntityName:(NSString*) entityName
{
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc] init];
    fetch.entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:context];
    NSString* predicateString;
    
    NSString* predicate = [self buildPredicateWithFieldName:[self getPrimaryKeyAttribute :entityName] values:values];
    
    predicateString = [predicate stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    fetch.predicate = [NSPredicate predicateWithFormat:predicate];
    NSArray *array = [context executeFetchRequest:fetch error:nil];
    return array;
}

/**
 */
- (BOOL) isValidRelation : (NSString*) relationName {
    
    if ([relationName isEqualToString:REL_SPECIALITYTOPROCEDURE] ||
        [relationName isEqualToString:REL_PRODUCTTOPROCEDURE] ||
        [relationName isEqualToString:REL_PROCEDURETOPRODUCT] ||
        [relationName isEqualToString:REL_MARKETTOPRODUCT] ||
        [relationName isEqualToString:REL_PROCEDURETOPROCEDURESTEP] ||
        [relationName isEqualToString:REL_PROCEDURESTEPTOPRODUCT] ||
        [relationName isEqualToString:REL_PRODUCTTOPROCEDURESTEP] ||
        [relationName isEqualToString:REL_PROCEDURESTEPTOCONCERN] ||
        [relationName isEqualToString:REL_CONCERNTOPROCEDURESTEP] ||
        [relationName isEqualToString:REL_CONCERNTOPRODUCT] ||
        [relationName isEqualToString:REL_PRODUCTTOCONCERN] ||
        [relationName isEqualToString:REL_PRODUCTTOPROCSTEP] ||
        [relationName isEqualToString:REL_PROCEDURESTEPTOPROCEDURE]
        /*|| [relationName isEqualToString:@"ProductToCompProduct"]*/
        )
    {
        return TRUE;
    }
    return FALSE;
}

@end